<?php
	session_start();
	if(!isset($_SESSION['usu']))
		header('location:index.php');
?>
<!DOCTYPE html>
<html lang="es">
	<head>
		<meta charset="utf-8">
		<title>Pagina de usuario gestor</title>
		<meta name="description" content="">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
		<!-- fontAwesone -->
	    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
		<!-- hoja de estilos -->
		<link rel="stylesheet" href="css/gestor_css.css">
	</head>
	<body>
		<header class="container mt-3">
			<div class="row">
				<div class="col-md-3">
					<img src="img/logo.png" class="img-fluid">
				</div>
				<div class="col-md-7">
					<h1 class="mt-2 text-center">Bienvenido GESTOR <?php echo $_SESSION['usu']; ?></h1>
				</div>
				<div class="col-md-2">
					<a class="mt-2 btn btn-info" href="logout.php">Desconectar</a>
				</div>
			</div>
		</header>
		<main>
			<div class="container">
				<div class="row">
					<div class="col-md-8 offset-md-2">
						<section>
							<h3 class="mt-4 text-center">Datos de los Provedores existentes</h3>
							<table class="table table-striped text-center">
								<thead>
									<tr>
										<th scope="col">nif</th>
										<th scope="col">nombre</th>
										<th scope="col">director</th>
										<th scope="col">estado</th>
										<th scope="col">ubicacion</th>
										<th scope="col" colspan="2">Acciones</th>
									</tr>
								</thead>
								<tbody>
									<?php
										require_once('bd/leerBD.php');
										$o= new leerBD();
										$datos=array();
										$datos=$o->selecionaProvedor();
										for($i=0;$i<count($datos);$i++){
									?>
									<tr>
										<th scope="row"><?php echo $datos[$i]['nif']; ?></th>
										<td><?php echo $datos[$i]['nombre'];?> </td>
										<td><?php echo $datos[$i]['director'];  ?></td>
										<td><?php echo $datos[$i]['estado']==1?"En servicio":" En reposo";?></td>
										<td><?php echo $datos[$i]['ubicacion']  ?></td>
										<td>
											<a href="actualizar_provedores.php?nif=<?php echo $datos[$i]['nif']; ?>" class="btn btn-warning">Actualizar</a>
										</td>
									</tr>
									<?php } ?>
								</tbody>
							</table>
						</section>
					</div>
				</div>
			</div>
		<div class="container-fluid">
				<div class="row mt-2 text-center">
					<div class="offset-md-1"></div>
					<div class="col-md-3">
						<a class="btn-info btn-lg " href="agregar_provedor.php">Agregar Provedor</a>
					</div>
					<div class="offset-md-1"></div>
					<div class="col-md-3">
						<a class="btn-info btn-lg " href="alta_solicitud.php">Crear Solicitud</a>
					</div>
					<div class="offset-md-1"></div>
					<div class="col-md-3">
						<a class="btn-primary btn-lg " href="ver_incidencias.php">Ver Incidencia</a>
					</div>
				</div>
		</div>
<div class="container">
					<div class="row">
							<div class="col-md-4 offset-md-4">
							<a href="contactos_enviados.php" class="btn btn-lg btn-block btn-light mt-5" >Ver Contactos Enviadas</a>
							</div>
					</div>
			</div>
<?php include('pie.php'); ?>