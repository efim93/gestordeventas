<html lang="es">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <title>Index Proyecto</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/css.css">
  </head>
  <body>
    <header>
    <h1 class="mt-2 text-center">LIBROS MADRID SL</h1>
  </header>
  <main>
    <div class="container">
      <div class="row">
        <div class="col-md-4 offset-md-4 especial">
          <h2 class="mt-3 text-center">Bienvenido</h2>
          <form action="validacion.php">
            <div class="form-group" mehot="get">
              <label for="user" class="mt-2">User</label>
              <input type="text" class="form-control" id="usuario"  placeholder="nombre de usuario" name="usuario">
            </div>
            <div class="form-group">
              <label for="password">Password</label>
              <input type="password" class="form-control" id="password" placeholder="contraseña" name="password">
            </div>
            <div class="col-md-6 offset-md-3">
            <button type="submit" class="btn btn-primary btn-lg">Login</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </main>
  </body>
</html>