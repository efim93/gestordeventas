<?php session_start();
	if(!isset($_SESSION['usu']))
		header('location:index.php');   ?>
<!DOCTYPE html>
<html lang="es">
	<head>
		<meta charset="utf-8">
		<title>Pagina usuario corriente</title>
		<meta name="description" content="">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
		<!-- Fuentes: Oxygen y Ballo Tamma -->
		<link href="https://fonts.googleapis.com/css?family=Baloo+Tamma|Oxygen" rel="stylesheet">
		 	<!-- fontAwesone -->
	    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
	</head>
<body>
<header class="container mt-3">
			<div class="row">
				<div class="col-md-3">
					<a href="
					<?php 
				switch ($_SESSION['usu']) {
						case 'efim':
						echo 'usuario_Corriente.php';
						break;
						case 'fulano':
						echo 'usuario_Director.php';
						break;
						case 'mengano':
						echo 'usuario_Gestor.php';
						break;
							}

					 ?>

					"><img src="img/logo.png" class="img-fluid"></a>
				</div>
				<div class="col-md-7">
					<h1 class="mt-2 text-center"></h1>
				</div>
				<div class="col-md-2">
					<a class="mt-2 btn btn-info btn-lg" href="logout.php">Desconectar</a>
				</div>
			</div>
</header>