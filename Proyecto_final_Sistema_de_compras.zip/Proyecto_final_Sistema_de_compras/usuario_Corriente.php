<?php
	session_start();
	if(!isset($_SESSION['usu']))
		header('location:index.php');
?>
<!DOCTYPE html>
<html lang="es">
	<head>
		<meta charset="utf-8">
		<title>Pagina usuario corriente</title>
		<meta name="description" content="">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
		 	<!-- fontAwesone -->
	    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
	    <!-- Fuentes: Oxygen y Ballo Tamma -->
		<link href="https://fonts.googleapis.com/css?family=Baloo+Tamma|Oxygen" rel="stylesheet">
	    	<!-- hoja de estilos -->
		<link rel="stylesheet" href="css/usuario_css.css">
	</head>
	<body>
		<header class="container mt-3">
			<div class="row">
				<div class="col-md-3">
					<img src="img/logo.png" class="img-fluid">
				</div>
				<div class="col-md-7">
					<h1 class="mt-2 text-center">Bienvenido USUARIO <?php echo $_SESSION['usu']; ?></h1>
				</div>
				<div class="col-md-2">
					<a class="mt-2 btn btn-info" href="logout.php">Desconectar</a>
				</div>
			</div>
		</header>
		<main>
			<div class="container">
				<div class="row">
					<div class="col-md-6">
								<h4 class="mt-3 text-justify">Rellena el formulario de solicitud</h4>
							<form action="insertar_solicitud.php" method="get">
								<label for="concepto">Concepto*:</label>
								<textarea id="unico" name="concepto" placeholder="Escribe aqui tu concepto" class="form-control"></textarea>
								<label for="cantidad">Cantidad*:</label>
								<input type="text" name="cantidad" class="form-control" placeholder="cantidad">
								<label for="provedor">Provedor:</label>
								<select name="provedor" class="form-control">
									<?php
										require_once('bd/leerBD.php');
										$o= new leerBD();
										$datos=$o->selecionaProvedor();
										for($i=0;$i<count($datos);$i++){
									?>
									<option><?php echo $datos[$i]['nombre']; ?></option>
									<?php } ?>
								</select>
								<label for="accion">Accion:</label>
								<select name="tipo_compra" class="form-control">
									<option value="p">Producto</option>
									<option value="s">Servicio</option>
								</select>
								<label for="precio">Precio</label>
								<input type="text" name="precio" placeholder="introduce precio requerido" class="form-control">
								<div class="col-md-4 offset-md-4">
									<input type="submit" class="mt-3 btn-success btn-lg " value="Solicita"/>
								</form>

							</div>
					</div>
					<div class="col-md-6">
						<h3 class="mt-5 text-center">Solicitudes Enviadas Correctamente</h3>
						<table class="table table-striped text-center colorido">
							<thead>
								<tr>
									<th scope="col">Id</th>
									<th scope="col">Concepto</th>
									<th scope="col">Cantidad</th>
									<th scope="col">Precio</th>
									<th scope="col">Aprobacion</th>
								</tr>
							</thead>
							<tbody>
								<?php
									$sole=array();
									$sole=$o->selecionaSolicitudes(1);
									for($i=0;$i<count($sole);$i++){
								?>
								<tr>
									<th scope="row"><?php echo $sole[$i]['idsolicitud']; ?></th>
									<td><?php echo $sole[$i]['concepto'];?> </td>
									<td><?php echo $sole[$i]['cantidad'];  ?></td>
									<td><?php echo $sole[$i]['precio'] .'€';  ?></td>
									<td><?php 
											switch($sole[$i]['aprobacion']){
												case 0:
												echo "en espera";
												break;
												case 1:
												echo "Acceptado";
													break;
												case 2:
												echo "Denegado";
													break;
												}
											 ?></td>
								</tr>
								<?php } ?>
							</tbody>
						</table>
				</div>
			</div>
			<div class="container">
					<div class="row">
							<div class="col-md-4 offset-md-4">
							<a href="contactos_enviados.php" class="btn btn-lg btn-block btn-light mt-5" >Ver Contactos Enviadas</a>
							</div>
					</div>
			</div>
			<?php include('pie.php'); ?>