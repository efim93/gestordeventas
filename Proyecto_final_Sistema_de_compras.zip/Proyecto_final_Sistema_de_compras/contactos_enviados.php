<?php 

include_once('cabecera.php');
require_once('bd/leerBD.php');
$o=new leerBD();
$datos=array();
$idusuario;
switch ($_SESSION['usu']) {
	case 'efim':
	$idusuario=1;
	break;
	case 'fulano':
	$idusuario=2;
	break;
	case 'mengano':
	$idusuario=3;
	break;
}

 ?>
	<body>
		 <main>
			<div class="row">
				<div class="col-md-8 offset-md-2">
					<table class="table table-hover table-dark mt-5">
					  <thead>
					    <tr>
					      <th scope="col">id</th>
					      <th scope="col">Nombre</th>
					      <th scope="col">Email</th>
					      <th scope="col">Mensaje</th>
					    </tr>
					  </thead>
					  <tbody> 
					<?php 

$datos=($idusuario==1)?$o->verContactos($idusuario):$o->verTodosContactos();
				
				for($i=0;$i<count($datos);$i++){
					 ?>
					 <tr>
					      <th scope="row"><?php echo $datos[$i]['idContacto']; ?></th>
					      <td><?php echo $datos[$i]['nombre']; ?></td>
					      <td><?php echo $datos[$i]['email']; ?></td>
					      <td><?php echo $datos[$i]['mensaje']; ?></td>
					    </tr>
					 <?php } ?>
					 </tbody>
					</table>
				</div>
			</div>
		</main>
	</body>
</html>