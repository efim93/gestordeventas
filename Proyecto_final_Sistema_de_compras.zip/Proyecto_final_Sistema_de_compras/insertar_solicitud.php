<?php 
include_once('cabecera.php');
require_once('bd/leerBD.php');
$idusuario;
switch ($_SESSION['usu']) {
	case 'efim':
	$idusuario=1;
	break;
	case 'fulano':
	$idusuario=2;
	break;
	case 'mengano':
	$idusuario=3;
	break;
}



$o= new leerBD();
if($_GET['concepto']!='' && $_REQUEST['cantidad']!='' ){
$o->insertarSolicitud($idusuario,$_GET['concepto'],$_REQUEST['precio'],
	$_REQUEST['cantidad'],$_REQUEST['tipo_compra'],$_REQUEST['provedor']);
}

switch ($_SESSION['usu']) {
	case 'efim':
	header('location:usuario_Corriente.php');
	break;
	case 'fulano':
	header('location:usuario_Director.php');
	break;
	case 'mengano':
	header('location:usuario_Gestor.php');
	break;
}


 ?>