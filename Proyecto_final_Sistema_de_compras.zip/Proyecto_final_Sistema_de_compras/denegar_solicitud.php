<?php 
require_once('bd/leerBD.php');
$o= new leerBD();
$o->denegarSolicitud($_GET['idsolicitud']);

 ?>