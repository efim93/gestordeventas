<?php include('cabecera.php') ?>
<div class="container">
				<div class="row">
					<div class="col-md-8 offset-md-2">
						<section>
							<h3 class="mt-4 text-center">Datos de los Provedores existentes</h3>
							<table class="table table-striped text-center">
								<thead>
									<tr>
										<th scope="col">nif</th>
										<th scope="col">nombre</th>
										<th scope="col">director</th>
										<th scope="col">estado</th>
										<th scope="col">ubicacion</th>
										<th scope="col" colspan="2">Acciones</th>
									</tr>
								</thead>
								<tbody>
									<?php
										require_once('bd/leerBD.php');
										$o= new leerBD();
										$datos=array();
										$datos=$o->selecionaProvedor();
										for($i=0;$i<count($datos);$i++){
									?>
									<tr>
										<th scope="row"><?php echo $datos[$i]['nif']; ?></th>
										<td><?php echo $datos[$i]['nombre'];?> </td>
										<td><?php echo $datos[$i]['director'];  ?></td>
										<td><?php echo $datos[$i]['estado']==1?"En servicio":" En reposo";?></td>
										<td><?php echo $datos[$i]['ubicacion']  ?></td>
										<td>
											<a href="actualizar_provedores.php?nif=<?php echo $datos[$i]['nif']; ?>" class="btn btn-warning">Actualizar</a>
										</td>
									</tr>
									<?php } ?>
								</tbody>
							</table>
						</section>
					</div>
				</div>
</main>
	</body>
</html>
