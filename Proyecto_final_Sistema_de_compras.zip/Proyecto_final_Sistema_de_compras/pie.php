</main>
		<footer>
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-12">
						<section>
							<h2 class="text-center">Contacto</h2>
						</section>
					</div>
				</div>
				<div class="row">
					<div class="col-md-6 offset-md-3">
						<form action="registra_contacto.php" id="formulario" method="get">
							<div class="form-group">
								<label for="nombre">Nombre*:</label>
								<input type="text" class="form-control" name="nombre" placeholder="Nombre" />
								<label for="email">Email*</label>
								<input type="text"  class="form-control" name="correo" placeholder="Email" />
								<label for="mensaje">Mensaje*:</label>
								<textarea class="form-control" name="mensaje" placeholder="Escribe tu mensaje" /></textarea>
								<input type="checkbox" name="acceptocondiciones">
								<label for="Accepto terminos y condicones">Accepto condiciones y términos de uso</label>
								<input type="submit"  class="form-control btn btn-success" name="enviar" id="enviar" value="Contacta con nosotros">
							</div>
						</form>
					</div>
				</div>
			</div>
		</footer>
	</body>
</html>