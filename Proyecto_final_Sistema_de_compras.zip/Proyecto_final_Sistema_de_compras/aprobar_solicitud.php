<?php 

require_once('bd/leerBD.php');
$o= new leerBD();
$o->aprobarSolicitud($_GET['idsolicitud']);


 ?>