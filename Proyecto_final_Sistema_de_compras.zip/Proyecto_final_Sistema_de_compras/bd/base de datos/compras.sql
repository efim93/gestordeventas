-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 13-09-2019 a las 14:38:57
-- Versión del servidor: 10.1.37-MariaDB
-- Versión de PHP: 7.3.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `compras`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `compra`
--

CREATE TABLE `compra` (
  `codigo` int(11) NOT NULL,
  `idsolicitud` int(11) NOT NULL,
  `nif_provedor` varchar(9) COLLATE ucs2_spanish2_ci NOT NULL,
  `fecha_compra` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=ucs2 COLLATE=ucs2_spanish2_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `contacta`
--

CREATE TABLE `contacta` (
  `idContacto` int(11) NOT NULL,
  `idusuario` int(11) NOT NULL,
  `nombre` varchar(40) COLLATE ucs2_spanish2_ci NOT NULL,
  `email` varchar(40) COLLATE ucs2_spanish2_ci NOT NULL,
  `mensaje` varchar(250) COLLATE ucs2_spanish2_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=ucs2 COLLATE=ucs2_spanish2_ci;

--
-- Volcado de datos para la tabla `contacta`
--

INSERT INTO `contacta` (`idContacto`, `idusuario`, `nombre`, `email`, `mensaje`) VALUES
(2, 1, 'EFIM', 'abraham@gmail.com', 'Quiero saber que pasa con mi solicitud...');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `provedor`
--

CREATE TABLE `provedor` (
  `nif` varchar(9) COLLATE ucs2_spanish2_ci NOT NULL,
  `nombre` varchar(40) COLLATE ucs2_spanish2_ci NOT NULL,
  `director` varchar(40) COLLATE ucs2_spanish2_ci NOT NULL,
  `estado` int(1) NOT NULL,
  `ubicacion` varchar(40) COLLATE ucs2_spanish2_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=ucs2 COLLATE=ucs2_spanish2_ci;

--
-- Volcado de datos para la tabla `provedor`
--

INSERT INTO `provedor` (`nif`, `nombre`, `director`, `estado`, `ubicacion`) VALUES
('00000000A', 'Mundo Papel Retiro', 'Jesus del Rioo', 1, ' C/ Gamonal 16, planta 2, nave 1, Madrid'),
('00000001B', 'Grupo Anaya', 'Alejandro Torez Cruzcampo', 1, ' C/ Telemaco 43, Madrid - Madrid'),
('00000003E', 'Pipiona', 'Ramona lopez', 1, 'Madrid - Madrid');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `solicitudes`
--

CREATE TABLE `solicitudes` (
  `idusuario` int(11) NOT NULL,
  `idsolicitud` int(11) NOT NULL,
  `aprobacion` int(1) NOT NULL DEFAULT '0',
  `incidencias` varchar(200) COLLATE ucs2_spanish2_ci NOT NULL,
  `concepto` varchar(40) COLLATE ucs2_spanish2_ci NOT NULL,
  `precio` int(11) NOT NULL DEFAULT '50',
  `cantidad` int(11) NOT NULL,
  `tipo_compra` varchar(1) COLLATE ucs2_spanish2_ci NOT NULL,
  `provedor_deseado` varchar(30) COLLATE ucs2_spanish2_ci NOT NULL,
  `fecha_inicio_solicitud` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=ucs2 COLLATE=ucs2_spanish2_ci;

--
-- Volcado de datos para la tabla `solicitudes`
--

INSERT INTO `solicitudes` (`idusuario`, `idsolicitud`, `aprobacion`, `incidencias`, `concepto`, `precio`, `cantidad`, `tipo_compra`, `provedor_deseado`, `fecha_inicio_solicitud`) VALUES
(1, 9, 1, 'se ha roto en camino', 'necesito bolígrafos para escribir', 30, 8, 'p', 'Grupo Anaya', '2019-09-05'),
(1, 10, 1, '', 'Se me ha roto la silla', 30, 1, 's', 'Pipiona', '2019-09-05'),
(1, 11, 2, '', 'libro', 50, 1, 'p', 'M', '2019-09-06'),
(1, 12, 0, '', 'lapiz', 3, 111, 'p', 'Grupo Anaya', '0000-00-00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `idusuario` int(11) NOT NULL,
  `nombre` varchar(40) COLLATE ucs2_spanish2_ci NOT NULL,
  `apellidos` varchar(40) COLLATE ucs2_spanish2_ci NOT NULL,
  `telefono` int(12) NOT NULL,
  `password` varchar(40) COLLATE ucs2_spanish2_ci NOT NULL,
  `correo` varchar(40) COLLATE ucs2_spanish2_ci NOT NULL,
  `tipo_usuario` int(1) NOT NULL,
  `fecha_nacimiento` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=ucs2 COLLATE=ucs2_spanish2_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`idusuario`, `nombre`, `apellidos`, `telefono`, `password`, `correo`, `tipo_usuario`, `fecha_nacimiento`) VALUES
(1, 'Efim', 'Ciubuc', 609179219, 'alumno', 'efimciubu@gmail.com', 1, '1993-07-27'),
(2, 'fulano', 'Fulano', 3330003, 'a123', 'fulano@yahoo.es', 3, '2009-09-01'),
(3, 'mengano', 'menganito', 999999991, 'pepe', 'mengano@yahoo.com', 2, '2000-06-01');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `compra`
--
ALTER TABLE `compra`
  ADD PRIMARY KEY (`codigo`),
  ADD KEY `nif_provedor` (`nif_provedor`),
  ADD KEY `idsolicitud` (`idsolicitud`);

--
-- Indices de la tabla `contacta`
--
ALTER TABLE `contacta`
  ADD PRIMARY KEY (`idContacto`),
  ADD KEY `idusuario` (`idusuario`);

--
-- Indices de la tabla `provedor`
--
ALTER TABLE `provedor`
  ADD PRIMARY KEY (`nif`);

--
-- Indices de la tabla `solicitudes`
--
ALTER TABLE `solicitudes`
  ADD PRIMARY KEY (`idusuario`,`idsolicitud`),
  ADD KEY `idsolicitud` (`idsolicitud`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`idusuario`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `compra`
--
ALTER TABLE `compra`
  MODIFY `codigo` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `contacta`
--
ALTER TABLE `contacta`
  MODIFY `idContacto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `solicitudes`
--
ALTER TABLE `solicitudes`
  MODIFY `idsolicitud` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `idusuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `compra`
--
ALTER TABLE `compra`
  ADD CONSTRAINT `compra_ibfk_1` FOREIGN KEY (`nif_provedor`) REFERENCES `provedor` (`nif`),
  ADD CONSTRAINT `compra_ibfk_2` FOREIGN KEY (`idsolicitud`) REFERENCES `solicitudes` (`idsolicitud`);

--
-- Filtros para la tabla `contacta`
--
ALTER TABLE `contacta`
  ADD CONSTRAINT `contacta_ibfk_1` FOREIGN KEY (`idusuario`) REFERENCES `usuarios` (`idusuario`);

--
-- Filtros para la tabla `solicitudes`
--
ALTER TABLE `solicitudes`
  ADD CONSTRAINT `solicitudes_ibfk_1` FOREIGN KEY (`idusuario`) REFERENCES `usuarios` (`idusuario`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
