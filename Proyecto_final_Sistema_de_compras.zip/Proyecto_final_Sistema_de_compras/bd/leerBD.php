<?php
require_once('conectar.php');

class leerBD{
	
	public function compruebaUsuario($nombre,$password){
		$conectar = new Conectar();
		$pdo = $conectar->conexion();
		$stmt = $pdo->prepare("SELECT nombre,password,tipo_usuario
							   FROM usuarios WHERE nombre=? and password=?");
		$stmt->execute(array($nombre,$password));
		$datos = array();
		
		while($result=$stmt->fetch(PDO::FETCH_ASSOC)){
			$datos[]=$result;
		}
		return $datos;
	}
		public function selecionaProvedor(){
			$conectar = new Conectar();
			$pdo = $conectar->conexion();
			$stmt = $pdo->prepare("SELECT *
								   FROM provedor");
			$stmt->execute();
			$datos = array();
			
			while($result=$stmt->fetch(PDO::FETCH_ASSOC)){
				$datos[]=$result;
			}
			return $datos;
		}

		public function selecionaSolicitudes($tipo_usuario){
			$conectar = new Conectar();
			$pdo = $conectar->conexion();
			$stmt = $pdo->prepare("SELECT *
								   FROM solicitudes s,usuarios u where s.idusuario=u.idusuario and tipo_usuario=?");
			$stmt->execute(array($tipo_usuario));
			$datos = array();
			while($result=$stmt->fetch(PDO::FETCH_ASSOC)){
				$datos[]=$result;
			}
			return $datos;
		}

		public function insertarSolicitud($idusuario,$concepto,$precio,$cantidad,$tipo,$provedor){
			try{	
				$conectar = new Conectar();
				$pdo = $conectar->conexion();
				$stmt = $pdo->prepare("INSERT INTO solicitudes(idusuario,idsolicitud,aprobacion,incidencias,concepto,precio,cantidad,tipo_compra,provedor_deseado) VALUES(?,null,0,'',?,?,?,?,?)");
				$stmt->execute(array($idusuario,$concepto,$precio,$cantidad,$tipo,$provedor));
				
			}catch(Exception $e){
				echo $e->getMessage();
				die("error en la conexion");
				}
		}

		public function verIncidencias(){
			try{	
				$conectar = new Conectar();
				$pdo = $conectar->conexion();
				$stmt = $pdo->prepare("SELECT * FROM solicitudes where incidencias !=''");
				$stmt->execute();
				$datos = array();
				while($result=$stmt->fetch(PDO::FETCH_ASSOC)){
					$datos[]=$result;
				}
			}catch(Exception $e){
				echo $e->getMessage();
				die("error en la conexion");
			}
			return $datos;
		}
		public function selecionaTodosSolicitudes(){
			$conectar = new Conectar();
			$pdo = $conectar->conexion();
			$stmt = $pdo->prepare("SELECT * FROM solicitudes s,usuarios u where s.idusuario=u.idusuario ORDER BY u.tipo_usuario");
			$stmt->execute(array());
			$datos = array();
			while($result=$stmt->fetch(PDO::FETCH_ASSOC)){
				$datos[]=$result;
			}
			return $datos;
		}

		public function altaProvedor($nif,$nombre,$director,$ubicacion){
			if($nif!='' && $nombre!=''){
			try{	
			$conectar = new Conectar();
			$pdo = $conectar->conexion();
			$stmt = $pdo->prepare("INSERT INTO provedor(nif,nombre,director,estado,ubicacion)
				VALUES(?,?,?,1,?)");
			$stmt->execute(array($nif,$nombre,$director,$ubicacion));
			}catch(Exception $e){
				echo $e->getMessage();
				die("error en la conexion");
			}
		}
		if($_SESSION['usu']=='mengano')
			header('location:usuario_Gestor.php');
		else
			header('location:usuario_Director.php');
		}
		public function aprobarSolicitud($idsolicitud){
			$conectar = new Conectar();
			$pdo = $conectar->conexion();
			$stmt = $pdo->prepare("UPDATE solicitudes SET aprobacion=1 WHERE idsolicitud LIKE ?");
			$stmt->execute(array($idsolicitud));
			header('location:usuario_Director.php');
		}
		public function denegarSolicitud($idsolicitud){
			$conectar = new Conectar();
			$pdo = $conectar->conexion();
			$stmt = $pdo->prepare("UPDATE solicitudes SET aprobacion=2 WHERE idsolicitud LIKE ?");
			$stmt->execute(array($idsolicitud));
			header('location:usuario_Director.php');
		}

		public function verProvedor($nif){
			$conectar = new Conectar();
			$pdo = $conectar->conexion();
			$stmt = $pdo->prepare("SELECT * FROM provedor WHERE nif=?");
			$stmt->execute(array($nif));
			$datos = array();
			while($result=$stmt->fetch(PDO::FETCH_ASSOC)){
				$datos[]=$result;
			}
			return $datos;
		}

		public function actualizarProvedor($nif,$nombre,$director,$ubicacion,$nif_antiguo){
		try{
			$conectar = new Conectar();
			$pdo = $conectar->conexion();
			$stmt = $pdo->prepare("UPDATE provedor SET nif = ?, nombre=?, director=?,ubicacion=? where nif=? ");
			$stmt->execute(array($nif,$nombre,$director,$ubicacion,$nif_antiguo));
		}catch(Exception $e){
				echo $e->getMessage();
				die("error en la conexion");
			}
		if($_SESSION['usu']=='mengano')
			header('location:usuario_Gestor.php');
		else
			header('location:usuario_Director.php');
		}

		public function registrarContacto($idusuario,$nombre,$email,$mensaje){
		try{
			$conectar = new Conectar();
			$pdo = $conectar->conexion();
			$stmt = $pdo->prepare("INSERT INTO contacta(idusuario,nombre,email,mensaje)
				VALUES(?,?,?,?)");
			$stmt->execute(array($idusuario,$nombre,$email,$mensaje));
			}catch(Exception $e){
				echo $e->getMessage();
				die("error en la conexion");
			}
		}
		public function verContactos($usuario){
			$conectar = new Conectar();
			$pdo = $conectar->conexion();
			$stmt = $pdo->prepare("SELECT * FROM contacta where idusuario=?");
				$stmt->execute(array($usuario));
				$datos = array();
				while($result=$stmt->fetch(PDO::FETCH_ASSOC)){
					$datos[]=$result;
				}
				return $datos;
		}
		public function verTodosContactos(){
			$conectar = new Conectar();
			$pdo = $conectar->conexion();
			$stmt = $pdo->prepare("SELECT * FROM contacta");
				$stmt->execute();
				$datos = array();
				while($result=$stmt->fetch(PDO::FETCH_ASSOC)){
					$datos[]=$result;
				}
				return $datos;
		}


}
?>