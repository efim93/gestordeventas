<?php
	session_start();
	if(!isset($_SESSION['usu']))
		header('location:index.php');
?>
<!DOCTYPE html>
<html lang="es">
	<head>
		<meta charset="utf-8">
		<title>Pagina de director</title>
		<meta name="description" content="">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
		 	<!-- fontAwesone -->
	    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
	    	<!-- hoja de estilos -->
		<link rel="stylesheet" href="./css/director_css.css">
	</head>
	<body>
		<header class="container mt-3">
			<div class="row">
				<div class="col-md-3">
					<img src="img/logo.png" class="img-fluid">
				</div>
				<div class="col-md-7">
					<h1 class="mt-2 text-center">Bienvenido Director <?php echo $_SESSION['usu']; ?></h1>
				</div>
				<div class="col-md-2">
					<a class="mt-2 btn btn-info btn-lg" href="logout.php">Desconectar</a>
				</div>
			</div>
		</header>
		<main>
			<div class="container">
				<div class="row">
					<div class="col-md-10">
							<h2 class=" text-center">Listado de solicitudes</h2>
							<table class="table table-striped text-center">
								<thead>
									<tr>
										<th scope="col">Id</th>
										<th scope="col">Concepto</th>
										<th scope="col">Cantidad</th>
										<th scope="col">Precio</th>
										<th scope="col">Aprobacion</th>
										<th scope="col">Fecha Peticion</th>
										<th scope="col">Aprobar</th>
										<th scope="col">Denegar</th>
									</tr>
								</thead>
								<tbody>
									<?php
									require_once('bd/leerBD.php');
										$o= new leerBD();
										$sole=array();
										$sole=$o->selecionaTodosSolicitudes();
										for($i=0;$i<count($sole);$i++){
									?>
									<tr>
										<th scope="row"><?php echo $sole[$i]['idsolicitud']; ?></th>
										<td><?php echo $sole[$i]['concepto'];?> </td>
										<td><?php echo $sole[$i]['cantidad'];  ?></td>
										<td><?php echo $sole[$i]['precio'];  ?></td>
										<td><?php 
											switch($sole[$i]['aprobacion']){
												case 0:
												echo "En espera";
												break;
												case 1:
												echo "Acceptado";
													break;
												case 2:
												echo "Denegado";
													break;
												}
											 ?></td>
										<td><?php echo $sole[$i]['fecha_inicio_solicitud']; ?></td>
										<td>
											<a href="aprobar_solicitud.php?idsolicitud=<?php echo $sole[$i]['idsolicitud'];?>">
												<i class="far fa-plus-square fa-2x"></i>
											</a>
										</td>
										<td>
											<a href="denegar_solicitud.php?idsolicitud=<?php echo $sole[$i]['idsolicitud'];?>">
												<i class="fas fa-minus fa-2x"></i>
											</a>
										</td>
									</tr>
									<?php } ?>
								</tbody>
							</table>
					</div>
					<div class="col-md-2">
						
						<a href="alta_solicitud.php" class="btn btn-block btn-warning mt-5" >Crear Solicitud
						</a>
						<a href="ver_provedores.php" class="btn btn-block btn-warning mt-4" >Ver Provedores
						</a>
						<a href="agregar_provedor.php" class="btn btn-warning btn-block mt-4" >Agregar Provedores
						</a>
							<a  href="ver_incidencias.php" class="btn btn-warning mt-4 btn-block">Ver Incidencias
						</a>
					</div>
				</div>
			</div>
			<div class="container">
					<div class="row">
							<div class="col-md-4 offset-md-4">
							<a href="contactos_enviados.php" class="btn btn-lg btn-block btn-light mt-5" >Ver los Contactos Enviados</a>
							</div>
					</div>
			</div>
		<?php include('pie.php'); ?>