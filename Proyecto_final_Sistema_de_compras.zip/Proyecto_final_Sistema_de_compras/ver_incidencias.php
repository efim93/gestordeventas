<?php  

include_once('cabecera.php');
require_once('bd/leerBD.php')

?>
<div class="row">
	<div class="col-md-8 offset-md-2">
						<h3 class="mt-4 text-center">Incidencias en solicitudes hechas</h3>
						<table class="table table-striped text-center">
							<thead>
								<tr>
									<th scope="col">Id_solicitud</th>
									<th scope="col">Concepto</th>
									<th scope="col">Aprobacion</th>
									<th scope="col">Incidencias</th>
								</tr>
							</thead>
							<tbody>
								<?php
								$o=new leerBD();
									$sole=array();
									$sole=$o->verIncidencias();
									for($i=0;$i<count($sole);$i++){
								?>
								<tr>
									<th scope="row"><?php echo $sole[$i]['idsolicitud']; ?></th>
									<td><?php echo $sole[$i]['concepto'];?> </td>
									<td><?php switch($sole[$i]['aprobacion']){
												case 0:
												echo "En espera";
												break;
												case 1:
												echo "Acceptado";
													break;
												case 2:
												echo "Denegado";
													break;
												}  ?></td>
									<td>
										<?php echo $sole[$i]['incidencias']; ?>
								</td>
								</tr>
								<?php } ?>
							</tbody>
						</table>
	</div>
</div>
</main>
	</body>
</html>

