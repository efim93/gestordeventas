<?php 
include_once('cabecera.php');
include_once('bd/leerBD.php');


$o=new leerBD();
$datos=array();
$datos=$o->verProvedor($_REQUEST['nif']);
 ?>
<div class="container">
<div class="row">
	<div class="col-md-6 offset-md-3">
		<h3 class="text-center mt-3">Actualiza los datos del provedor</h3>
<form action="actualizarProvedor.php">
 <?php
 
 for ($i=0; $i <count($datos) ; $i++) { 

?>
	<label>Nif</label>
	<input type="text" name="nif" class="form-control" value="<?php echo $datos[$i]['nif']; ?>">
	<label>Nombre</label>
	<input type="text" name="nombre" class="form-control" value="<?php echo $datos[$i]['nombre']; ?>">
	<label>Director</label>
	<input type="text" name="director" class="form-control" value="<?php echo $datos[$i]['director']; ?>">
	<label>Ubicacion</label>
	<input type="text" name="ubicacion" class="form-control" value="<?php echo $datos[$i]['ubicacion']; ?>">
	<br>
	<input type="hidden" name="nif_antiguo" value="<?php echo $datos[$i]['nif']; ?>" >									
	<input type="submit" name="enviar" value="Enviar datos" class="btn btn-success">


<?php
} ?>

</form>
</div>
</div>
</div>
</main>
	</body>
</html>
