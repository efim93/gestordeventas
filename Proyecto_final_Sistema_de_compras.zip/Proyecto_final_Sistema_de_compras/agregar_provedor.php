<?php

include_once('cabecera.php');

?>
<div class="row">
	<div class="col-md-6 offset-md-3">
		<h3 class="text-center mt-3">Rellena para Agregar provedor</h3>
<form action="alta_provedor.php">
	<label>Nif</label>
	<input type="text" name="nif" class="form-control">
	<label>Nombre</label>
	<input type="text" name="nombre" class="form-control">
	<label>Director</label>
	<input type="text" name="director" class="form-control">
	<label>Ubicacion</label>
	<input type="text" name="ubicacion" class="form-control">
	<br>
	<input type="submit" name="enviar" value="Enviar datos" class="btn btn-success">
</form>
</div>
</div>
</main>
	</body>
</html>
