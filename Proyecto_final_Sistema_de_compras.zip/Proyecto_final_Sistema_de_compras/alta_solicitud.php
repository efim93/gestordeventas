<?php include 'cabecera.php'; ?>
		<div class="container">
				<div class="row">
						<div class="col-md-8 offset-md-2">
							<h2 class="text-center mt-3">Rellena el formulario de solicitud</h2>
							<form action="insertar_solicitud.php" method="get">
								<label for="concepto">Concepto:</label>
								<textarea id="unico" name="concepto" placeholder="Escribe aqui tu concepto" class="form-control" style="resize: none;" ></textarea>
								<label for="cantidad">Cantidad:</label>
								<input type="text" name="cantidad" value="" class="form-control" placeholder="cantidad">
								<label for="provedor">Provedor:</label>
								
								<select name="provedor" class="form-control">
									<?php
										require_once('bd/leerBD.php');
										$o= new leerBD();
										$datos=$o->selecionaProvedor();
										for($i=0;$i<count($datos);$i++){
									?>
									<option><?php echo $datos[$i]['nombre']; ?></option>
									<?php } ?>
								</select>

								<label for="accion">Accion:</label>
								<select name="tipo_compra" class="form-control">
									<option value="p">Producto</option>
									<option value="s">Servicio</option>
								</select>
								<label for="precio">Precio</label>
								<input type="text" name="precio" placeholder="introduce precio requerido" class="form-control">
									<input type="submit" class="mt-3 btn-success btn-lg " value="Solicita"/>
								</form>
							</div>
					</div>
				</div>
		</main>
	</body>
</html>
