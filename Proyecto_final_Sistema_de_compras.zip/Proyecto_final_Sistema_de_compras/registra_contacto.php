 <?php 

include_once('cabecera.php');
require_once('bd/leerBD.php');
$idusuario;
switch ($_SESSION['usu']) {
	case 'efim':
	$idusuario=1;
	break;
	case 'fulano':
	$idusuario=2;
	break;
	case 'mengano':
	$idusuario=3;
	break;
}
if(isset($_REQUEST['acceptocondiciones'])){
	$o= new leerBD();
	if($_GET['nombre']!='' && $_REQUEST['correo']!='' && $_REQUEST['mensaje'] ){
		$o->registrarContacto($idusuario,$_GET['nombre'],$_REQUEST['correo'],$_REQUEST['mensaje']);
	}
}
switch ($_SESSION['usu']) {
	case 'efim':
	header('location:usuario_Corriente.php');
	break;
	case 'fulano':
	header('location:usuario_Director.php');
	break;
	case 'mengano':
	header('location:usuario_Gestor.php');
	break;
}


  ?>
  </div>
</div>
</main>
	</body>
</html>
