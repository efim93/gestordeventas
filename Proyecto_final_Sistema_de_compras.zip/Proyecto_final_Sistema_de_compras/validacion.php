<?php 
require_once('bd/leerBD.php');
	
$nombre=$_REQUEST['usuario'];
$password=$_REQUEST['password'];

$o= new leerBD();
$datos=$o->compruebaUsuario($nombre,$password);
		
if(count($datos)!=0){
	while($datos){ 
		switch ($datos[0]['tipo_usuario']) {
			case 1:
				session_start();
				$_SESSION['usu']=$nombre;
				header('location:usuario_Corriente.php');
				break;
			case 2:
				session_start();
				$_SESSION['usu']=$nombre;
				header('location:usuario_Gestor.php');
				break;
			case 3:
				session_start();
				$_SESSION['usu']=$nombre;
				header('location:usuario_Director.php');
				break;
		}
	}
}else{
	header('location:index.php');
}

 ?>