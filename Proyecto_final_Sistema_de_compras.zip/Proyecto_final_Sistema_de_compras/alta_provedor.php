<?php 
include_once('cabecera.php');
require_once('bd/leerBD.php');
$o= new leerBD();
$o->altaProvedor($_REQUEST['nif'],$_REQUEST['nombre'],$_REQUEST['director'],$_REQUEST['ubicacion'])

 ?>